<?php
    require("inc/PDO.php");
    require("inc/func.php");

    $error=array();
    $success=false;
if(!empty($_POST['submited'])){

    $titre= trim(strip_tags($_POST['titre']));
    $adresse= trim(strip_tags($_POST['adresse']));
    $ville= trim(strip_tags($_POST['ville']));
    $cp= trim(strip_tags($_POST['cp']));
    $surface= trim(strip_tags($_POST['surface']));
    $prix= trim(strip_tags($_POST['prix']));
    $type= $_POST['type'];

    if( isset($_FILES['photo']) && $_FILES['photo']['error'] == 0){
        if($_FILES['photo']['size']<=1500000){
            $info_file=pathinfo($_FILES['photo']['name']);
            $extention=$info_file['extension'];
            $ext_OK= array(
                'jpg',
                'jpeg',
                'gif',
                'png'
            );
            if(in_array($extention, $ext_OK)){
                echo("le fichier est bon ");
                move_uploaded_file($_FILES['photo']['tmp_name'], 'image/'.basename($_FILES['photo']['name']));
            }else{
                echo("format incorrecte");
            }
        }else{
            echo("fichier trop gros");
        }
    }else{

        echo("aucun fichier send");
    } $photo= $_POST['photo'];

    function verifCp($errors, $value, $key, $val){
        if (!empty($value)) {
            if (!is_numeric($value)) {
                $errors[$key] = ' veuillez renseigner un code postal';
            } elseif (mb_strlen($value) != $val) {     
                $errors[$key] = 'obligatoire ' . $val . ' caractéres';
            }
        } else {
            $errors[$key] = 'Veuillez renseigner ce champ';
        }
        return $errors;
    };
    $error=verifCp($error,$cp,"cp",5);

    if (count($error)==0){
        $success=true;

        $type= $_POST['type'];
        $description= trim(strip_tags($_POST['description']));


        $sql="INSERT INTO logement VALUES (NULL,:titre,:adresse,:ville,:cp,:surface,:prix,:type,:description,:photo)";
        $query=$pdo->prepare($sql);
        $query->bindValue(':titre',$titre,PDO::PARAM_STR);
        $query->bindValue(':adresse',$adresse,PDO::PARAM_STR);
        $query->bindValue(':ville',$ville,PDO::PARAM_STR);
        $query->bindValue(':cp',$cp,PDO::PARAM_INT);
        $query->bindValue(':surface',$surface,PDO::PARAM_INT);
        $query->bindValue(':prix',$prix,PDO::PARAM_INT);
        $query->bindValue(':photo',$photo,PDO::PARAM_STR);
        $query->bindValue(':type',$type,PDO::PARAM_STR);
        $query->bindValue(':description',$description,PDO::PARAM_STR);
        $query->execute(); 

        header("index.php");
    }
} 
    if ($success){
        echo "<p>inscription terminée</p><a href='index.php'>acceuil</a>";
    }else{
?>
<a href="index.php">retour a l'acceuil</a>

<form action="" method="POST" enctype="multipart/form-data">
    <label for="titre">titre</label>
        <input type="text" name="titre" value="<?php if (!empty($_POST['titre'])){echo $_POST['titre'];}?>">
        <?php errorInput($error,"titre")?>
    </br>
    <label for="adresse">adresse</label>
        <input type="text" name="adresse" value="<?php if (!empty($_POST['adresse'])){echo $_POST['adresse'];}?>">
        <?php errorInput($error,"adresse")?>
    </br>
    <label for="ville">ville</label>
        <input type="text" name="ville" value="<?php if (!empty($_POST['ville'])){echo $_POST['ville'];}?>">
        <?php errorInput($error,"ville")?>
    </br>
    <label for="cp">cp</label>
        <input type="number" name="cp" value="<?php if (!empty($_POST['cp'])){echo $_POST['cp'];}?>">
        <?php errorInput($error,"cp")?>
    </br>
    <label for="surface">surface</label>
        <input type="text" name="surface" value="<?php if (!empty($_POST['surface'])){echo $_POST['surface'];}?>">
        <?php errorInput($error,"surface")?>
    </br>
    <label for="prix">prix</label>
        <input type="text" name="prix" value="<?php if (!empty($_POST['prix'])){echo $_POST['prix'];}?>">
        <?php errorInput($error,"prix")?>
    </br>
    <label for="photo">photo</label>
        <input type="file" name="photo">
        <?php errorInput($error,"photo")?>
    </br>
        <select name="type">
            <option value="">choisir</option>
            <option value="vente">vente</option>
            <option value="location">location</option>
        </select>
    </br>
    <label for="description">description</label>
    </br>
        <textarea name="description" cols="30" rows="10"></textarea>
    </br>
    <input type="submit" name="submited">
</form>

<?php } ?>