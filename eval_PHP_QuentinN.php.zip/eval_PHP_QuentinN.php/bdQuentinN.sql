-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 28, 2020 at 12:01 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `immobilier`
--

-- --------------------------------------------------------

--
-- Table structure for table `logement`
--

CREATE TABLE `logement` (
  `id_logement` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `cp` int(11) NOT NULL,
  `surface` int(11) NOT NULL,
  `prix` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logement`
--

INSERT INTO `logement` (`id_logement`, `titre`, `adresse`, `ville`, `cp`, `surface`, `prix`, `type`, `description`, `photo`) VALUES
(1, 'test', 'test', 'test', 356, 467, 578, 'vente', '(è!hfjk', ''),
(2, 'jvhcdhcqskhjvqs', 'bjk:fbjk:fbk:j', 'bfebklsdvb;', 578689, 890678, 578679, 'vente', 'fhj;v', ''),
(3, 'jvhcdhcqskhjvqs', 'bjk:fbjk:fbk:j', 'bfebklsdvb;', 578689, 890678, 578679, 'vente', 'fhj;v', ''),
(4, 'jvhcdhcqskhjvqs', 'bjk:fbjk:fbk:j', 'bfebklsdvb;', 578689, 890678, 578679, 'vente', 'fhj;v', ''),
(5, '', '', '', 0, 0, 0, 'vente', '', ''),
(6, 'test2', 'test2', 'test2', 12456, 568, 6897, '', '', ''),
(7, 'b;j', 'bjk', 'chjn', 57985, 0, 0, '', '', ''),
(8, 'b;j', 'bjk', 'chjn', 57985, 0, 0, '', '', ''),
(9, 'b;j', 'bjk', 'chjn', 57985, 0, 0, '', '', ''),
(10, 'b;j', 'bjk', 'chjn', 57985, 0, 0, '', '', ''),
(11, '', '', '', 46786, 0, 0, '', '', ''),
(12, '', '', '', 46786, 0, 0, '', '', ''),
(13, '', '', '', 46868, 0, 0, '', '', ''),
(14, '', '', '', 46868, 0, 0, '', '', ''),
(15, '', '', '', 12345, 0, 0, NULL, '', ''),
(16, '', '', '', 12345, 0, 0, '', '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logement`
--
ALTER TABLE `logement`
  ADD PRIMARY KEY (`id_logement`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logement`
--
ALTER TABLE `logement`
  MODIFY `id_logement` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
