<?php
        require("inc/PDO.php");
        require("inc/func.php");


    $sql="SELECT * FROM logement";
    $query=$pdo->prepare($sql);
    $query->execute();
    $offres=$query->fetchAll();
?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<h1>index</h1>
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>titre</th>
                    <th>adresse</th>
                    <th>ville</th>
                    <th>cp</th>
                    <th>surface</th>
                    <th>prix</th>
                    <th>photo</th>
                    <th>type</th>
                    <th>description</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                // Boucle sur chaque élément de notre tableau de client
                foreach($offres as $key=>$value){
                ?>
                <tr>
                    <td><?= $value['titre'] ?></td>
                    <td><?= $value['adresse'] ?></td>
                    <td><?= $value['ville'] ?></td>
                    <td><?= $value['cp'] ?></td>
                    <td><?= $value['surface'] ?></td>
                    <td><?= $value['prix'] ?></td>
                    <td><?= $value['photo']?></td>
                    <td><?= $value['type'] ?></td>
                    <td><?= $value['description'] ?></td>
                </tr>
                <?php    
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<a href="ajouter.php"><button>ajouter une offre</button></a>
