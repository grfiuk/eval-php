<?php
    function debug(array $tab){
        echo'<pre>';
        print_r($tab);
        echo'<pre>';
    }        
    function verifChamp($errors,$value,$key,$min,$max){
        if(!empty($value)){
            if(mb_strlen($value)<$min){
                $errors[$key]='min '.$min.' caracteres';
            }elseif(mb_strlen($value)>$max){
                $errors[$key]='max '.$max.' caracteres';
            }
        }else{
            $errors[$key]='veuillez remplir ce champ';
        }   
        return $errors;
    }
    function verifEmail($errors,$value,$key){
        if(!empty($value)){
            if(!filter_var($value,FILTER_VALIDATE_EMAIL)){
                $errors[$key]='mail invalide';
            }
        }else{
                $errors[$key]='champ vide';
        }
        return $errors;
    }
    function verifPop($errors, $value, $key, $min, $max){
        if (!empty($value)) {
            if (!is_numeric($value)) {
                $errors[$key] = ' veuillez renseigner un nombre';
            } elseif (mb_strlen($value) < $min) {
                $errors[$key] = 'minimum ' . $min . ' caractéres';
            } elseif (mb_strlen($value) > $max) {
                $errors[$key] = 'maximum ' . $max . ' caractéres';
            }
        } else {
        $errors[$key] = 'Veuillez renseigner ce champ';
        }
        return $errors;
    };
    function verifCountry($errors, $value, $key, $val){
        if (!empty($value)) {
            if (is_numeric($value)) {
                $errors[$key] = ' veuillez renseigner des lettres';
            } elseif (mb_strlen($value) != $val) {     
                $errors[$key] = 'obligatoire ' . $val . ' caractéres';
            }
        } else {
            $errors[$key] = 'Veuillez renseigner ce champ';
        }
        return $errors;
    };
    function errorInput($errors,$key){
        if(!empty($errors[$key])){
            echo'<p class="error">'.$errors[$key].'</p>';
        }
    }
    function paginationIdea($page,$num,$count) {
        echo '<div class="pagination">';
        if ($page > 1){
            echo '<a href="index.php?page=' . ($page - 1) . '" class="btn btn-primary">Précédent</a>';
        }
         //n'affiche le lien vers la page suivante que s'il y en a une
         //basée sur le count() de MYSQL
        if ($page*$num < $count) {   
            echo '<a href="index.php?page=' . ($page + 1) . '" class="btn btn-primary">Suivant</a>';
        }
    
        echo '</div>';
    }
    function mdp($error,$value,$value2,$key){
        if($value==$value2){
            if(mb_strlen($value)>=6 && mb_strlen($value)<=255){
            }else{
                $error[$key]="pas ok";
            }
        }else{
            echo"pas ok";
        }
        return $error;
    }
    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    function isLogged(){
        if(!empty($_SESSION['user'])){
            if(!empty($_SESSION['user']['id']) && is_numeric($_SESSION['user']['id'])){
                if(!empty($_SESSION['user']['pseudo'])){
                    if(!empty($_SESSION['user']['role'])){
                        if(!empty($_SESSION['user']['ip'])){    
                            if($_SESSION['user']['ip']==$_SERVER['REMOTE_ADDR']){
                                return true; 
                            }                 
                        }
                    }
                }
            }
        }
        return false;
    }
    function isAdmin(){
        if(isLogged()){
            if($_SESSION['user']['role']=='admin'){
                return true;
            }
        }
        return false;
    }
